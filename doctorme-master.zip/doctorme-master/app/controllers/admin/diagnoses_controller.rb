require 'admin/admin_controller.rb'
class Admin::DiagnosesController < AdminController
  before_action :set_diagnosis, only: [:show, :edit, :update, :destroy]

  # GET /diagnoses
  # GET /diagnoses.json
  def index
    @diagnoses = Diagnosis.all
  end

  # GET /diagnoses/1
  # GET /diagnoses/1.json
  def show
  end

  # GET /diagnoses/new
  def new
    @diagnosis = Diagnosis.new
  end

  # GET /diagnoses/1/edit
  def edit
  end

  # POST /diagnoses
  # POST /diagnoses.json
  def create
    @diagnosis = Diagnosis.new(diagnosis_params)

    respond_to do |format|
      if @diagnosis.save
        format.html { redirect_to admin_diagnoses_path, notice: 'Diagnosis was successfully created.' }
      else
        format.html { render :new }
      end
    end
  end

  # PATCH/PUT /diagnoses/1
  # PATCH/PUT /diagnoses/1.json
  def update
    if params[:diagnosis][:primary_medications].present?
      @diagnosis.primary_diagnosis_medications.destroy_all

      primary_medication_ids = params[:diagnosis][:primary_medications].reject { |m| m.empty? }

      primary_medication_ids.each do |medication_id|
        @diagnosis.diagnosis_medications.find_or_initialize_by(medication_id: medication_id, position: 0)
      end
    end


    if params[:diagnosis][:secondary_medications].present?
      @diagnosis.secondary_diagnosis_medications.destroy_all

      secondary_medication_ids = params[:diagnosis][:secondary_medications].reject { |m| m.empty? }
      
      secondary_medication_ids.each do |medication_id|
        @diagnosis.diagnosis_medications.find_or_initialize_by(medication_id: medication_id, position: 1)
      end
    end

    respond_to do |format|
      if @diagnosis.update!(diagnosis_params)
        format.html { redirect_to admin_diagnoses_path, notice: 'Diagnosis was successfully updated.' }
      else
        format.html { render :edit }
      end
    end
  end

  # DELETE /diagnoses/1
  # DELETE /diagnoses/1.json
  def destroy
    @diagnosis.destroy
    respond_to do |format|
      format.html { redirect_to admin_diagnoses_path, notice: 'Diagnosis was successfully destroyed.' }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_diagnosis
      @diagnosis = Diagnosis.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def diagnosis_params
      params.require(:diagnosis).permit(:title,
                                        :description,
                                        :age_min,
                                        :age_max,
                                        :gender,
                                        medication_ids: [])
    end
end

require 'admin/admin_controller.rb'
class Admin::MedicationsController < AdminController
  before_action :set_medication, only: [:show, :edit, :update, :destroy]

  # GET /medications
  # GET /medications.json
  def index
    @medications = Medication.all
  end

  # GET /medications/1
  # GET /medications/1.json
  def show
  end

  # GET /medications/new
  def new
    @medication = Medication.new
  end

  # GET /medications/1/edit
  def edit
  end

  # POST /medications
  # POST /medications.json
  def create
    @medication = Medication.new(medication_params)

    respond_to do |format|
      if @medication.save
        format.html { redirect_to admin_medications_path, notice: 'Medication was successfully created.' }
      else
        format.html { render :new }
      end
    end
  end

  # PATCH/PUT /medications/1
  # PATCH/PUT /medications/1.json
  def update
    respond_to do |format|
      if @medication.update(medication_params)
        format.html { redirect_to admin_medications_path, notice: 'Medication was successfully updated.' }
      else
        format.html { render :edit }
      end
    end
  end

  # DELETE /medications/1
  # DELETE /medications/1.json
  def destroy
    @medication.destroy
    respond_to do |format|
      format.html { redirect_to admin_medications_path, notice: 'Medication was successfully destroyed.' }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_medication
      @medication = Medication.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def medication_params
      params.require(:medication).permit(:title,
                                         :description,
                                         :age_min,
                                         :age_max,
                                         :gender,
                                         :image,
                                         :medication_type,
                                         consideration_ids: [],
                                         diagnosis_ids: [])
    end
end
